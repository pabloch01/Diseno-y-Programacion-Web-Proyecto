(function () {
    'use strict';

    var opciones, btnCrearCuenta, btnCancelar;
    var tipoSeleccionado = null;

    var DESTINOS = {
        administrador: 'dashboard.html',
        terapeuta: 'dashboard_terapeuta.html',
        encargado: 'dashboard-encargado.html'
    };

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        opciones = document.querySelectorAll('.user-type-option');
        btnCrearCuenta = document.getElementById('btn-crear-cuenta');
        btnCancelar = document.getElementById('btn-cancelar-tipo-usuario');

        opciones.forEach(function (opcion) {
            opcion.addEventListener('click', function () {
                seleccionarTipo(opcion);
            });
        });

        btnCancelar.addEventListener('click', function () {
            window.history.back();
        });

        btnCrearCuenta.addEventListener('click', function () {
            if (btnCrearCuenta.disabled || !tipoSeleccionado) { return; }
            ValidacionesLogin.notificar('Cuenta creada. Ingresando al sistema...', 'exito');
            ValidacionesLogin.redirigirConRetraso(DESTINOS[tipoSeleccionado]);
        });
    }

    function seleccionarTipo(opcionElegida) {
        opciones.forEach(function (opcion) {
            opcion.classList.remove('user-type-option--selected');
            opcion.setAttribute('aria-pressed', 'false');
        });
        opcionElegida.classList.add('user-type-option--selected');
        opcionElegida.setAttribute('aria-pressed', 'true');
        tipoSeleccionado = opcionElegida.dataset.tipo;
        btnCrearCuenta.disabled = false;
    }
})();
