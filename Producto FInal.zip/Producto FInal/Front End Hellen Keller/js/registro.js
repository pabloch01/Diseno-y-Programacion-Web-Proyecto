(function () {
    'use strict';

    var inputEmail, inputPassword, inputRepite, btnTipoUsuario, btnCancelar;

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        inputEmail = document.getElementById('input-email-registro');
        inputPassword = document.getElementById('input-password-registro');
        inputRepite = document.getElementById('input-repite-registro');
        btnTipoUsuario = document.getElementById('btn-tipo-usuario');
        btnCancelar = document.getElementById('btn-cancelar-registro');

        inputEmail.addEventListener('input', validarFormulario);
        inputPassword.addEventListener('input', validarFormulario);
        inputRepite.addEventListener('input', validarFormulario);

        btnCancelar.addEventListener('click', function () {
            window.history.back();
        });

        btnTipoUsuario.addEventListener('click', function () {
            if (btnTipoUsuario.disabled) { return; }
            ValidacionesLogin.notificar('Datos válidos. Continuemos con el tipo de usuario.', 'exito');
            ValidacionesLogin.redirigirConRetraso('tipo-usuario.html');
        });
    }

    function validarFormulario() {
        var emailValido = ValidacionesLogin.email(inputEmail.value);
        var passwordValida = ValidacionesLogin.contrasena(inputPassword.value);
        var repiteValida = ValidacionesLogin.coinciden(inputRepite.value, inputPassword.value);

        ValidacionesLogin.alternarError(
            'error-email-registro',
            inputEmail.value.length > 0 && !emailValido,
            'Ingrese un correo electrónico válido.'
        );
        ValidacionesLogin.alternarError(
            'error-password-registro',
            inputPassword.value.length > 0 && !passwordValida,
            'Debe incluir mayúscula, minúscula y número (mínimo 8 caracteres).'
        );
        ValidacionesLogin.alternarError(
            'error-repite-registro',
            inputRepite.value.length > 0 && !repiteValida,
            'Las contraseñas no coinciden.'
        );

        btnTipoUsuario.disabled = !(emailValido && passwordValida && repiteValida);
    }
})();
