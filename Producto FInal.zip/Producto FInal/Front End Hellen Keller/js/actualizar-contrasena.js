(function () {
    'use strict';

    var inputEmail, inputPassword, inputRepite, btnActualizar, btnCancelar;

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        inputEmail = document.getElementById('input-email-actualizar');
        inputPassword = document.getElementById('input-password-actualizar');
        inputRepite = document.getElementById('input-repite-actualizar');
        btnActualizar = document.getElementById('btn-actualizar');
        btnCancelar = document.getElementById('btn-cancelar-actualizar');

        inputEmail.addEventListener('input', validarFormulario);
        inputPassword.addEventListener('input', validarFormulario);
        inputRepite.addEventListener('input', validarFormulario);

        btnCancelar.addEventListener('click', function () {
            window.history.back();
        });

        btnActualizar.addEventListener('click', function () {
            if (btnActualizar.disabled) { return; }
            ValidacionesLogin.notificar('Contraseña actualizada correctamente.', 'exito');
            ValidacionesLogin.redirigirConRetraso('identificarse.html');
        });
    }

    function validarFormulario() {
        var emailValido = ValidacionesLogin.email(inputEmail.value);
        var passwordValida = ValidacionesLogin.contrasena(inputPassword.value);
        var repiteValida = ValidacionesLogin.coinciden(inputRepite.value, inputPassword.value);

        ValidacionesLogin.alternarError(
            'error-email-actualizar',
            inputEmail.value.length > 0 && !emailValido,
            'Ingrese un correo electrónico válido.'
        );
        ValidacionesLogin.alternarError(
            'error-password-actualizar',
            inputPassword.value.length > 0 && !passwordValida,
            'Debe incluir mayúscula, minúscula y número (mínimo 8 caracteres).'
        );
        ValidacionesLogin.alternarError(
            'error-repite-actualizar',
            inputRepite.value.length > 0 && !repiteValida,
            'Las contraseñas no coinciden.'
        );

        btnActualizar.disabled = !(emailValido && passwordValida && repiteValida);
    }
})();
