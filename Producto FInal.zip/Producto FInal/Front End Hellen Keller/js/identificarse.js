(function () {
    'use strict';

    var inputEmail, inputPassword, btnIniciarSesion, btnCancelar;

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        inputEmail = document.getElementById('input-email-identificarse');
        inputPassword = document.getElementById('input-password-identificarse');
        btnIniciarSesion = document.getElementById('btn-iniciar-sesion');
        btnCancelar = document.getElementById('btn-cancelar-identificarse');

        inputEmail.addEventListener('input', validarFormulario);
        inputPassword.addEventListener('input', validarFormulario);

        btnCancelar.addEventListener('click', function () {
            window.history.back();
        });

        btnIniciarSesion.addEventListener('click', function () {
            if (btnIniciarSesion.disabled) { return; }
            ValidacionesLogin.notificar('Bienvenido/a. Iniciando sesión...', 'exito');
            ValidacionesLogin.redirigirConRetraso('tipo-usuario.html');
        });
    }

    function validarFormulario() {
        var emailValido = ValidacionesLogin.email(inputEmail.value);
        var passwordValida = ValidacionesLogin.contrasena(inputPassword.value);

        ValidacionesLogin.alternarError(
            'error-email-identificarse',
            inputEmail.value.length > 0 && !emailValido,
            'Ingrese un correo electrónico válido.'
        );
        ValidacionesLogin.alternarError(
            'error-password-identificarse',
            inputPassword.value.length > 0 && !passwordValida,
            'Debe incluir mayúscula, minúscula y número (mínimo 8 caracteres).'
        );

        btnIniciarSesion.disabled = !(emailValido && passwordValida);
    }
})();
