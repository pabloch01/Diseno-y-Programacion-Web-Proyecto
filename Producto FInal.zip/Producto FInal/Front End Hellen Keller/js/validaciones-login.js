(function () {
    'use strict';

    var REGEX_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var REGEX_CONTRASENA = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

    function esEmailValido(valor) {
        return REGEX_EMAIL.test((valor || '').trim());
    }

    function esContrasenaValida(valor) {
        return REGEX_CONTRASENA.test(valor || '');
    }

    function contrasenasCoinciden(valorA, valorB) {
        return valorA.length > 0 && valorA === valorB;
    }

    function alternarError(idSpan, hayError, mensaje) {
        var span = document.getElementById(idSpan);
        if (!span) { return; }
        if (hayError) {
            span.textContent = mensaje;
            span.classList.add('error-visible');
        } else {
            span.textContent = '';
            span.classList.remove('error-visible');
        }
    }

    function mostrarNotificacion(mensaje, tipo) {
        var contenedor = document.getElementById('contenedor-notificaciones');
        if (!contenedor) { return; }
        var notif = document.createElement('div');
        notif.className = 'notificacion notificacion--' + tipo;
        notif.textContent = mensaje;
        contenedor.appendChild(notif);
        setTimeout(function () {
            notif.classList.add('notificacion--salir');
            setTimeout(function () { notif.remove(); }, 300);
        }, 3000);
    }

    function redirigirConRetraso(url, retrasoMs) {
        setTimeout(function () {
            window.location.href = url;
        }, retrasoMs || 900);
    }

    window.ValidacionesLogin = {
        email: esEmailValido,
        contrasena: esContrasenaValida,
        coinciden: contrasenasCoinciden,
        alternarError: alternarError,
        notificar: mostrarNotificacion,
        redirigirConRetraso: redirigirConRetraso
    };
})();
