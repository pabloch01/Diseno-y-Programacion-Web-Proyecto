(function () {
    'use strict';

    var inputPassword, inputRepite, btnActualizar, btnCancelar;

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        inputPassword = document.getElementById('input-password-nueva');
        inputRepite = document.getElementById('input-repite-nueva');
        btnActualizar = document.getElementById('btn-actualizar-nueva');
        btnCancelar = document.getElementById('btn-cancelar-nueva');

        inputPassword.addEventListener('input', validarFormulario);
        inputRepite.addEventListener('input', validarFormulario);

        /* Excepcion pedida: no usa history.back(), siempre vuelve al paso 1 */
        btnCancelar.addEventListener('click', function () {
            window.location.href = 'restablecer-contrasena.html';
        });

        btnActualizar.addEventListener('click', function () {
            if (btnActualizar.disabled) { return; }
            ValidacionesLogin.notificar('Contraseña restablecida correctamente.', 'exito');
            ValidacionesLogin.redirigirConRetraso('identificarse.html');
        });
    }

    function validarFormulario() {
        var passwordValida = ValidacionesLogin.contrasena(inputPassword.value);
        var repiteValida = ValidacionesLogin.coinciden(inputRepite.value, inputPassword.value);

        ValidacionesLogin.alternarError(
            'error-password-nueva',
            inputPassword.value.length > 0 && !passwordValida,
            'Debe incluir mayúscula, minúscula y número (mínimo 8 caracteres).'
        );
        ValidacionesLogin.alternarError(
            'error-repite-nueva',
            inputRepite.value.length > 0 && !repiteValida,
            'Las contraseñas no coinciden.'
        );

        btnActualizar.disabled = !(passwordValida && repiteValida);
    }
})();
