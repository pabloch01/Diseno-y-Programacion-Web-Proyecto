(function () {
    'use strict';

    var inputEmail, btnRestablecer, btnCancelar;

    document.addEventListener('DOMContentLoaded', inicializar);

    function inicializar() {
        inputEmail = document.getElementById('input-email-restablecer');
        btnRestablecer = document.getElementById('btn-restablecer');
        btnCancelar = document.getElementById('btn-cancelar-restablecer');

        inputEmail.addEventListener('input', validarFormulario);

        btnCancelar.addEventListener('click', function () {
            window.history.back();
        });

        btnRestablecer.addEventListener('click', function () {
            if (btnRestablecer.disabled) { return; }
            window.location.href = 'restablecer-enviado.html';
        });
    }

    function validarFormulario() {
        var emailValido = ValidacionesLogin.email(inputEmail.value);

        ValidacionesLogin.alternarError(
            'error-email-restablecer',
            inputEmail.value.length > 0 && !emailValido,
            'Ingrese un correo electrónico válido.'
        );

        btnRestablecer.disabled = !emailValido;
    }
})();
